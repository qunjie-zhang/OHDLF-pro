from .main import run

_version_='1.0'
if __name__ == '__main__':
    run()
